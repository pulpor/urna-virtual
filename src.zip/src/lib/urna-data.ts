import candidatosJson from "../candidatos.json";

export interface Candidate {
  numero: string; // 4 digits
  nome: string;
  partido: string;
  vice?: string;
  foto?: string; // url or initials fallback
}

export const DEFAULT_CANDIDATES: Candidate[] = candidatosJson;
