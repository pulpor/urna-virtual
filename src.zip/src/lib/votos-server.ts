import { createServerFn } from "@tanstack/react-start";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const VOTOS_PATH = join(process.cwd(), "votos.json");

type Tally = Record<string, number>;

function read(): Tally {
  if (!existsSync(VOTOS_PATH)) return {};
  try {
    return JSON.parse(readFileSync(VOTOS_PATH, "utf-8")) as Tally;
  } catch {
    return {};
  }
}

function write(tally: Tally) {
  writeFileSync(VOTOS_PATH, JSON.stringify(tally, null, 2));
}

export const getVotos = createServerFn({ method: "GET" }).handler(
  (): Tally => read(),
);

export const registrarVoto = createServerFn({ method: "POST" })
  .inputValidator((key: string) => key)
  .handler(({ data: key }): Tally => {
    const tally = read();
    tally[key] = (tally[key] ?? 0) + 1;
    write(tally);
    return tally;
  });

export const zerarVotos = createServerFn({ method: "POST" }).handler(
  (): Tally => {
    write({});
    return {};
  },
);
