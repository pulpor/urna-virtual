// Web Audio synthesizer for the urna sounds — no audio files needed.
let ctx: AudioContext | null = null;

function getCtx(): AudioContext {
  if (!ctx) {
    const AC = (window.AudioContext || (window as any).webkitAudioContext);
    ctx = new AC();
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

function tone(freq: number, duration: number, type: OscillatorType = "sine", volume = 0.15, delay = 0) {
  const c = getCtx();
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  const start = c.currentTime + delay;
  gain.gain.setValueAtTime(0, start);
  gain.gain.linearRampToValueAtTime(volume, start + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
  osc.connect(gain).connect(c.destination);
  osc.start(start);
  osc.stop(start + duration + 0.05);
}

export const sounds = {
  key: () => tone(1100, 0.08, "square", 0.08),
  confirm: () => {
    tone(880, 0.12, "sine", 0.18);
    tone(1320, 0.18, "sine", 0.15, 0.1);
  },
  error: () => {
    tone(220, 0.18, "sawtooth", 0.15);
    tone(180, 0.22, "sawtooth", 0.12, 0.08);
  },
  fim: () => {
    tone(523, 0.18, "sine", 0.18);
    tone(659, 0.18, "sine", 0.18, 0.18);
    tone(784, 0.32, "sine", 0.2, 0.36);
  },
};
