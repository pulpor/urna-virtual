import { createFileRoute } from "@tanstack/react-router";
import { Urna } from "@/components/Urna";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Urna Eletrônica Sesc 2026" },
      {
        name: "description",
        content:
          "Simulador interativo da urna eletrônica brasileira — vote, cadastre candidatos e veja os resultados.",
      },
    ],
  }),
});

function Index() {
  return <Urna />;
}
