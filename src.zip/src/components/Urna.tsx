/**
 * Urna Eletrônica Virtual
 * Autor: Leonardo Pulpor — Professor de Programação
 * Projeto: 3º Ano · Técnico em Informática para Web
 * Instituição: SESC SENAC · 2026
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { sounds } from "@/lib/urna-sounds";
import { DEFAULT_CANDIDATES, type Candidate } from "@/lib/urna-data";
import { getVotos, registrarVoto, zerarVotos } from "@/lib/votos-server";

type Stage = "input" | "fim";

interface Tally {
  [key: string]: number; // numero or "BRANCO" or "NULO"
}

const PRESIDENT_DIGITS = 4;

export function Urna() {
  const [digits, setDigits] = useState<string>("");
  const [stage, setStage] = useState<Stage>("input");
  const [candidates, setCandidates] = useState<Candidate[]>(DEFAULT_CANDIDATES);
  const [tally, setTally] = useState<Tally>({});
  const [adminOpen, setAdminOpen] = useState(false);
  const [confirmFlash, setConfirmFlash] = useState(false);
  const [pressedKey, setPressedKey] = useState<string | null>(null);
  const fimTimer = useRef<number | null>(null);

  // Carrega votos do arquivo ao montar
  useEffect(() => {
    getVotos().then(setTally).catch(() => {});
  }, []);

  const candidate = useMemo(() => {
    if (digits.length !== PRESIDENT_DIGITS) return null;
    return candidates.find((c) => c.numero === digits) ?? null;
  }, [digits, candidates]);

  const isBranco = digits === "BRANCO";
  const isNulo = digits.length === PRESIDENT_DIGITS && !candidate && !isBranco;

  const reset = useCallback(() => {
    setDigits("");
    setStage("input");
    setConfirmFlash(false);
  }, []);

  const pressDigit = useCallback(
    (d: string) => {
      if (stage !== "input") return;
      if (isBranco) return;
      if (digits.length >= PRESIDENT_DIGITS) return;
      setDigits((prev) => prev + d);
      sounds.key();
    },
    [digits, stage, isBranco],
  );

  const pressBranco = useCallback(() => {
    if (stage !== "input") return;
    if (digits.length > 0 && !isBranco) {
      sounds.error();
      return;
    }
    sounds.key();
    setDigits("BRANCO");
  }, [stage, digits, isBranco]);

  const pressCorrige = useCallback(() => {
    if (stage !== "input") return;
    sounds.error();
    setDigits("");
  }, [stage]);

  const pressConfirma = useCallback(() => {
    if (stage !== "input") return;
    if (digits.length < PRESIDENT_DIGITS && !isBranco) {
      sounds.error();
      return;
    }
    setConfirmFlash(true);
    sounds.confirm();
    const key = isBranco ? "BRANCO" : candidate ? candidate.numero : "NULO";
    setTally((prev) => ({ ...prev, [key]: (prev[key] ?? 0) + 1 })); // otimista
    registrarVoto({ data: key }).then(setTally).catch(() => {});
    setTimeout(() => {
      setStage("fim");
      sounds.fim();
      fimTimer.current = window.setTimeout(reset, 3500);
    }, 350);
  }, [stage, digits, isBranco, candidate, reset]);

  // Keyboard support
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (adminOpen) return;
      if (e.key >= "0" && e.key <= "9") {
        pressDigit(e.key);
        flashKey(e.key);
      } else if (e.key === "Enter") {
        pressConfirma();
        flashKey("CONF");
      } else if (e.key === "Backspace" || e.key === "Escape") {
        pressCorrige();
        flashKey("CORR");
      } else if (e.key.toLowerCase() === "b") {
        pressBranco();
        flashKey("BRAN");
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [pressDigit, pressConfirma, pressCorrige, pressBranco, adminOpen]);

  useEffect(() => {
    return () => {
      if (fimTimer.current) clearTimeout(fimTimer.current);
    };
  }, []);

  const flashKey = (k: string) => {
    setPressedKey(k);
    setTimeout(() => setPressedKey(null), 100);
  };

  const renderDigits = () => {
    const slots = Array.from({ length: PRESIDENT_DIGITS }, (_, i) => {
      const ch = !isBranco && digits[i] ? digits[i] : "";
      const blink = !isBranco && i === digits.length && stage === "input";
      return (
        <div key={i} className={`digit-box ${blink ? "blink" : ""}`}>
          {ch}
        </div>
      );
    });
    return <div className="screen-digits">{slots}</div>;
  };

  return (
    <div className="urna-page">
      <div className="urna-body">
        <div className="urna-brand">
          <h1>URNA ELETRÔNICA</h1>
          <span className="tse">SESC · SENAC</span>
        </div>

        {/* VISOR */}
        <div className="urna-screen">
          <div className="screen-header">
            <span>Eleição 2026 · 1º Turno</span>
            <span>Cargo: PRESIDENTE</span>
          </div>

          {stage === "fim" ? (
            <div className="screen-fim">FIM</div>
          ) : isBranco ? (
            <>
              <div className="screen-message branco">VOTO EM BRANCO</div>
              <div className="screen-footer">
                Confirma: VERDE · Corrige: LARANJA
              </div>
            </>
          ) : isNulo ? (
            <>
              <div className="screen-row">
                <span className="screen-label">Seu voto para presidente</span>
              </div>
              <div className="screen-row">
                <span className="screen-label">Número:</span>
                {renderDigits()}
              </div>
              <div className="screen-message nulo">VOTO NULO</div>
              <div className="screen-footer">
                Confirma: VERDE · Corrige: LARANJA
              </div>
            </>
          ) : candidate ? (
            <>
              <div className="screen-row">
                <span className="screen-label">Seu voto para presidente</span>
              </div>
              <div className="screen-row">
                <span className="screen-label">Número:</span>
                {renderDigits()}
              </div>
              <div className="candidate-row">
                <div className="candidate-info">
                  <p className="name">{candidate.nome}</p>
                  <p>Partido: {candidate.partido}</p>
                  {candidate.vice && <p>Vice: {candidate.vice}</p>}
                </div>
                <div className="candidate-photo">
                  {candidate.foto ? (
                    <img src={candidate.foto} alt={candidate.nome} />
                  ) : (
                    candidate.nome.charAt(0)
                  )}
                </div>
              </div>
              <div className="screen-footer">
                CONFIRME SEU VOTO
                <div className="hint">Verde CONFIRMA · Laranja CORRIGE</div>
              </div>
            </>
          ) : (
            <>
              <div className="screen-row">
                <span className="screen-label">Seu voto para presidente</span>
              </div>
              <div className="screen-row">
                <span className="screen-label">Número:</span>
                {renderDigits()}
              </div>
              <div className="screen-footer">
                Digite o número do candidato
                <div className="hint">Use o teclado físico ou do computador</div>
              </div>
            </>
          )}
        </div>

        {/* TECLADO */}
        <div className="urna-keypad">
          <div className="key-grid">
            {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((n) => (
              <button
                key={n}
                className={`key ${pressedKey === n ? "pressed" : ""}`}
                onClick={() => {
                  pressDigit(n);
                  flashKey(n);
                }}
              >
                {n}
              </button>
            ))}
            <div />
            <button
              className={`key ${pressedKey === "0" ? "pressed" : ""}`}
              onClick={() => {
                pressDigit("0");
                flashKey("0");
              }}
            >
              0
            </button>
            <div />
          </div>
          <div className="action-row">
            <button
              className="key-action key-branco"
              onClick={() => {
                pressBranco();
                flashKey("BRAN");
              }}
            >
              Branco
            </button>
          </div>
          <div className="action-row">
            <button
              className="key-action key-corrige"
              onClick={() => {
                pressCorrige();
                flashKey("CORR");
              }}
            >
              Corrige
            </button>
            <button
              className={`key-action key-confirma ${confirmFlash ? "flash" : ""}`}
              onClick={() => {
                pressConfirma();
                flashKey("CONF");
              }}
            >
              Confirma
            </button>
          </div>
        </div>
      </div>

      <button
        className="admin-trigger"
        title="Painel administrativo"
        onClick={() => setAdminOpen(true)}
        aria-label="Abrir painel administrativo"
      />

      {adminOpen && (
        <AdminPanel
          candidates={candidates}
          setCandidates={setCandidates}
          tally={tally}
          onZerarVotos={() => zerarVotos().then(setTally).catch(() => {})}
          onClose={() => setAdminOpen(false)}
        />
      )}
    </div>
  );
}

function AdminPanel({
  candidates,
  setCandidates,
  tally,
  onZerarVotos,
  onClose,
}: {
  candidates: Candidate[];
  setCandidates: (c: Candidate[]) => void;
  tally: Tally;
  onZerarVotos: () => void;
  onClose: () => void;
}) {
  const [form, setForm] = useState<Candidate>({ numero: "", nome: "", partido: "", vice: "" });

  const totalVotes = Object.values(tally).reduce((a, b) => a + b, 0);

  function downloadVotos() {
    const data = {
      exportadoEm: new Date().toISOString(),
      totalVotos: totalVotes,
      votos: Object.fromEntries(
        Object.entries(tally).map(([key, qty]) => [labelFor(key), qty]),
      ),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "votos.json";
    a.click();
    URL.revokeObjectURL(url);
  }
  const sorted = Object.entries(tally).sort((a, b) => b[1] - a[1]);

  const labelFor = (key: string) => {
    if (key === "BRANCO") return "Voto em Branco";
    if (key === "NULO") return "Voto Nulo";
    const c = candidates.find((x) => x.numero === key);
    return c ? `${c.numero} · ${c.nome} (${c.partido})` : `${key} (removido)`;
  };

  return (
    <div className="admin-modal" onClick={onClose}>
      <div className="admin-panel" onClick={(e) => e.stopPropagation()}>
        <h2>Painel Administrativo</h2>
        <p style={{ opacity: 0.7, fontSize: 13 }}>
          Total de votos: <strong>{totalVotes}</strong>
        </p>

        <h3>Resultados</h3>
        {sorted.length === 0 ? (
          <p style={{ opacity: 0.5, fontSize: 13 }}>Nenhum voto registrado.</p>
        ) : (
          sorted.map(([k, v]) => {
            const pct = totalVotes ? (v / totalVotes) * 100 : 0;
            return (
              <div className="result-row" key={k}>
                <div className="top">
                  <span>{labelFor(k)}</span>
                  <strong>
                    {v} ({pct.toFixed(1)}%)
                  </strong>
                </div>
                <div className="bar-track">
                  <div className="bar" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })
        )}

        <h3>Candidatos cadastrados</h3>
        {candidates.map((c) => (
          <div className="result-row" key={c.numero}>
            <div className="top">
              <span>
                <strong>{c.numero}</strong> · {c.nome} ({c.partido})
              </span>
              <button
                className="danger"
                style={{ padding: "4px 10px", borderRadius: 4, border: "none", color: "#fff", cursor: "pointer" }}
                onClick={() => setCandidates(candidates.filter((x) => x.numero !== c.numero))}
              >
                Remover
              </button>
            </div>
          </div>
        ))}

        <h3>Novo candidato</h3>
        <div className="admin-form">
          <input
            placeholder="Número (4 dígitos)"
            value={form.numero}
            maxLength={PRESIDENT_DIGITS}
            onChange={(e) => setForm({ ...form, numero: e.target.value.replace(/\D/g, "") })}
          />
          <input
            placeholder="Partido"
            value={form.partido}
            onChange={(e) => setForm({ ...form, partido: e.target.value.toUpperCase() })}
          />
          <input
            placeholder="Nome"
            value={form.nome}
            onChange={(e) => setForm({ ...form, nome: e.target.value })}
            style={{ gridColumn: "1 / -1" }}
          />
          <input
            placeholder="Vice (opcional)"
            value={form.vice ?? ""}
            onChange={(e) => setForm({ ...form, vice: e.target.value })}
            style={{ gridColumn: "1 / -1" }}
          />
        </div>

        <div className="admin-actions">
          <button
            onClick={() => {
              if (form.numero.length !== PRESIDENT_DIGITS || !form.nome || !form.partido) return;
              if (candidates.some((c) => c.numero === form.numero)) return;
              setCandidates([...candidates, form]);
              setForm({ numero: "", nome: "", partido: "", vice: "" });
            }}
          >
            Adicionar
          </button>
          <button
            className="danger"
            onClick={() => {
              if (confirm("Zerar todos os votos?")) onZerarVotos();
            }}
          >
            Zerar votos
          </button>
          <button onClick={downloadVotos}>
            Baixar votos.json
          </button>
          <button className="secondary" onClick={onClose}>
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
